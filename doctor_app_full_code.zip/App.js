
// Root App
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import RootNavigator from './src/navigation/RootNavigator';
import { CallProvider } from './src/context/CallContext';

export default function App(){
 return(
  <CallProvider>
    <NavigationContainer>
      <RootNavigator/>
    </NavigationContainer>
  </CallProvider>
 );
}
