
import React from'react';
import{TouchableOpacity,Text,View}from'react-native';

export default function Card({item,onPress}){
 return(
 <TouchableOpacity onPress={onPress}
   style={{padding:16,backgroundColor:'#fff',borderRadius:12,marginBottom:12}}>
   <Text>{item.patientName}</Text>
   <Text>{item.status}</Text>
 </TouchableOpacity>);
}
