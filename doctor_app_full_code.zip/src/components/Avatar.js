
import React from'react';
import{View,Text}from'react-native';

export default function Avatar({name='JP'}){
 return(
  <View style={{width:60,height:60,borderRadius:30,backgroundColor:'#FDF8E5',justifyContent:'center',alignItems:'center'}}>
    <Text>{name[0]}</Text>
  </View>);
}
