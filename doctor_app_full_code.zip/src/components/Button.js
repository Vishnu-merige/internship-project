
import React from'react';
import{TouchableOpacity,Text}from'react-native';

export default function Button({title,onPress,type='primary'}){
 return(
 <TouchableOpacity onPress={onPress}
   style={{padding:14,borderRadius:10,backgroundColor:type==='danger'?'red':'#3A643B',marginVertical:6}}>
   <Text style={{color:'#fff',textAlign:'center'}}>{title}</Text>
 </TouchableOpacity>);
}
