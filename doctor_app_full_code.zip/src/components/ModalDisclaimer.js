
import React from'react';
import{Modal,View,Text}from'react-native';
import Button from './Button';

export default function ModalDisclaimer({visible,onProceed,onCancel}){
 return(
 <Modal visible={visible} transparent animationType="fade">
  <View style={{flex:1,backgroundColor:'#0008',justifyContent:'center',alignItems:'center'}}>
   <View style={{backgroundColor:'#fff',padding:20,borderRadius:14,width:'80%'}}>
    <Text style={{fontWeight:'700'}}>Disclaimer</Text>
    <Text style={{marginVertical:10}}>Video call will start when you click proceed.</Text>
    <Button title="Proceed" onPress={onProceed}/>
    <Button title="Cancel" type="danger" onPress={onCancel}/>
   </View>
  </View>
 </Modal>
 );
}
