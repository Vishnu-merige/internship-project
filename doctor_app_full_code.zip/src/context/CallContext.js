
import React,{createContext,useContext,useState}from'react';
const CallContext=createContext(null);

export function CallProvider({children}){
 const[callState,setCallState]=useState({status:'idle',caller:null,callee:null,roomId:null});

 const startCallAsDoctor=({doctor,patient,appointmentId})=>{
   const roomId=`room_${doctor.id}_${appointmentId}`;
   setCallState({status:'outgoing',caller:doctor,callee:patient,roomId});
   return roomId;
 };

 return <CallContext.Provider value={{callState,setCallState,startCallAsDoctor}}>{children}</CallContext.Provider>;
}

export const useCall=()=>useContext(CallContext);
