
import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import AppointmentsList from '../screens/Appointments/AppointmentsList';
import { View,Text } from 'react-native';

const Tab=createBottomTabNavigator();
const Placeholder=({title})=><View style={{flex:1,justifyContent:'center',alignItems:'center'}}><Text>{title}</Text></View>

export default function DoctorTabs(){
 return(
  <Tab.Navigator screenOptions={{headerShown:false}}>
    <Tab.Screen name="Appointments" component={AppointmentsList}/>
    <Tab.Screen name="Patients" children={()=> <Placeholder title="Patients"/>}/>
    <Tab.Screen name="Profile" children={()=> <Placeholder title="Profile"/>}/>
  </Tab.Navigator>
 );
}
