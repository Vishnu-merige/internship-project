
import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Splash from '../screens/Splash';
import DoctorTabs from './DoctorTabs';
import AppointmentDetails from '../screens/Appointments/AppointmentDetails';
import IncomingCall from '../screens/Calling/IncomingCall';
import OutgoingCall from '../screens/Calling/OutgoingCall';
import WaitingForPickup from '../screens/Calling/WaitingForPickup';
import VideoCall from '../screens/Calling/VideoCall';
import CallEnded from '../screens/Calling/CallEnded';

const Stack=createNativeStackNavigator();

export default function RootNavigator(){
 return(
  <Stack.Navigator screenOptions={{headerShown:false}}>
    <Stack.Screen name="Splash" component={Splash}/>
    <Stack.Screen name="Tabs" component={DoctorTabs}/>
    <Stack.Screen name="AppointmentDetails" component={AppointmentDetails}/>
    <Stack.Screen name="IncomingCall" component={IncomingCall}/>
    <Stack.Screen name="OutgoingCall" component={OutgoingCall}/>
    <Stack.Screen name="WaitingForPickup" component={WaitingForPickup}/>
    <Stack.Screen name="VideoCall" component={VideoCall}/>
    <Stack.Screen name="CallEnded" component={CallEnded}/>
  </Stack.Navigator>
 );
}
