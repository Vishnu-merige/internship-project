
import React,{useState}from'react';
import {View,Text,TouchableOpacity,ScrollView}from'react-native';
import Button from '../../components/Button';
import Avatar from '../../components/Avatar';
import ModalDisclaimer from '../../components/ModalDisclaimer';
import {useCall} from'../../context/CallContext';

const TABS=['Summary','Symptoms','Reports','Medication'];

export default function Details({route,navigation}){
 const{appointment,doctor}=route.params;
 const[tab,setTab]=useState('Summary');
 const[show,setShow]=useState(false);
 const{startCallAsDoctor}=useCall();

 const proceed=()=>{
   const roomId=startCallAsDoctor({doctor,patient:{id:'p1',name:appointment.patientName},appointmentId:appointment.id});
   setShow(false);
   navigation.navigate('OutgoingCall',{roomId,patient:{name:appointment.patientName},doctor});
 };

 return(
 <View style={{flex:1,padding:20}}>
   <ScrollView>
    <View style={{flexDirection:'row',alignItems:'center'}}>
     <Avatar name={appointment.patientName}/>
     <Text style={{marginLeft:10}}>{appointment.patientName}</Text>
    </View>

    <View style={{flexDirection:'row',marginVertical:20}}>
     {TABS.map(t=>
      <TouchableOpacity key={t} onPress={()=>setTab(t)} style={{padding:10,backgroundColor:tab===t?'#3A643B':'#eee',marginRight:6}}>
        <Text style={{color:tab===t?'#fff':'#000'}}>{t}</Text>
      </TouchableOpacity>
     )}
    </View>

    <Text>{tab} content goes here...</Text>
   </ScrollView>

   <Button title="Start Call" onPress={()=>setShow(true)}/>
   <ModalDisclaimer visible={show} onProceed={proceed} onCancel={()=>setShow(false)}/>
 </View>);
}
