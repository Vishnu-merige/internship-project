
import React from'react';
import {View,FlatList}from'react-native';
import AppointmentCard from '../../components/AppointmentCard';

const doctor={id:'doctor_1',name:'Dr'};
const appts=[{id:'1',patientName:'JP',patientInitials:'JP',datetime:new Date().toISOString(),status:'Upcoming'}];

export default function AppointmentsList({navigation}){
 return(
 <View style={{flex:1,padding:20}}>
  <FlatList data={appts} keyExtractor={i=>i.id}
    renderItem={({item})=>(
      <AppointmentCard item={item}
        onPress={()=>navigation.navigate('AppointmentDetails',{appointment:item,doctor})}/>
    )}
  />
 </View>);
}
