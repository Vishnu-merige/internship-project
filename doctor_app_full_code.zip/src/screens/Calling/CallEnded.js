
import React from'react';
import{View,Text}from'react-native';
import Button from '../../components/Button';

export default function Ended({navigation}){
 return(
 <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
  <Text>Call Ended</Text>
  <Button title="Back" onPress={()=>navigation.reset({index:0,routes:[{name:'Tabs'}]})}/>
 </View>);
}
