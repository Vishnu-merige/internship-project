
import React from'react';
import{View,Text}from'react-native';
import Button from '../../components/Button';
import Avatar from '../../components/Avatar';

export default function Incoming({route,navigation}){
 const{caller,roomId}=route.params||{caller:{name:'Doctor'},roomId:'demo'};
 return(
 <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
  <Avatar name={caller.name}/>
  <Text>Incoming Call</Text>
  <Button title="Accept" onPress={()=>navigation.replace('VideoCall',{roomId,userId:'patient1',userName:'JP'})}/>
  <Button title="Decline" type="danger" onPress={()=>navigation.replace('CallEnded')}/>
 </View>);
}
