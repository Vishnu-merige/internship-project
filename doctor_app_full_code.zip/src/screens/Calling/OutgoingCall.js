
import React from'react';
import{View,Text}from'react-native';
import Button from '../../components/Button';
import Avatar from '../../components/Avatar';

export default function Outgoing({route,navigation}){
 const{patient,roomId,doctor}=route.params;
 return(
 <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
  <Avatar name={patient.name}/>
  <Text>Calling {patient.name}...</Text>
  <Button title="Simulate Ringing" onPress={()=>navigation.replace('WaitingForPickup',{patient,roomId,doctor})}/>
  <Button title="Cancel" type="danger" onPress={()=>navigation.replace('CallEnded')}/>
 </View>);
}
