
import React from'react';
import{View}from'react-native';
import ZegoUIKitPrebuiltCall,{ONE_ON_ONE_VIDEO_CALL_CONFIG}from'@zegocloud/zego-uikit-prebuilt-call-rn';
import{ZEGOCLOUD_APP_ID,ZEGOCLOUD_APP_SIGN}from'../../config/zego';

export default function VC({route,navigation}){
 const{roomId,userId,userName}=route.params;
 return(
  <View style={{flex:1}}>
   <ZegoUIKitPrebuiltCall 
     appID={ZEGOCLOUD_APP_ID}
     appSign={ZEGOCLOUD_APP_SIGN}
     userID={String(userId)}
     userName={userName}
     callID={roomId}
     config={{...ONE_ON_ONE_VIDEO_CALL_CONFIG,onHangUp:()=>navigation.replace('CallEnded')}}
   />
  </View>);
}
