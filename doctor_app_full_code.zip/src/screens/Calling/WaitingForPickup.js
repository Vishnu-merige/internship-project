
import React from'react';
import{View,Text}from'react-native';
import Button from '../../components/Button';
import Avatar from '../../components/Avatar';

export default function Waiting({route,navigation}){
 const{patient,roomId,doctor}=route.params;
 return(
 <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
  <Avatar name={patient.name}/>
  <Text>Waiting for consumer to pick up...</Text>
  <Button title="Simulate Pickup" onPress={()=>navigation.replace('VideoCall',{roomId,userId:doctor.id,userName:doctor.name})}/>
  <Button title="End Call" type="danger" onPress={()=>navigation.replace('CallEnded')}/>
 </View>);
}
