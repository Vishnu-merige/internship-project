
export default {primary:'#3A643B'};
